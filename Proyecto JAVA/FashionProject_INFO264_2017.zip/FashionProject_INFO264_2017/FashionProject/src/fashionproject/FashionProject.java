package fashionproject;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FashionProject {

    public static void main(String[] args) {
        // TODO code application logic here
        //mysql db = new mysql();
        //db.MySQLConnect();
        
        /*Login login = new Login();
        System.out.println("Hola Grupo!!");
        login.show();
        ConexionBD cnBD = new ConexionBD();
        cnBD.conexion();*/
        PantallaPrincipal pp = new PantallaPrincipal();
        pp.show();

    }
    
}
