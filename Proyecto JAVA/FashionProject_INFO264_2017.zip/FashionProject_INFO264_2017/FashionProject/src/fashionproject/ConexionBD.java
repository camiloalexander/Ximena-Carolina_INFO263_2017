
package fashionproject;
import java.sql.*;

public class ConexionBD {
    Connection cn;
    private static String db="bd_peluqueria";
    private static String user="root";
    private static String pass="root";
    private static String host="localhost";
    private static String server="jdbc:mysql://"+host+"/"+db;
    
    public static Connection conexion(){
        Connection cn = null;
        try{ 
            Class.forName("com.mysql.jdbc.Driver"); //vamos a usar mysql
            cn = DriverManager.getConnection(server,user,pass);
            System.out.println("Conexion Exitosa!");
        }catch(Exception ex){
            System.out.println(String.valueOf(ex));
        }
        return cn;
    }
    
    public static ResultSet getTabla(String Consulta){
        Connection cn = conexion();
        Statement st;
        ResultSet datos = null;
        try{
            st=cn.createStatement();
            datos=st.executeQuery(Consulta);
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
        return datos;
        
    }
    
    
    Statement createStatement(){
        throw new UnsupportedOperationException("No soportado!");
        
    }
}
